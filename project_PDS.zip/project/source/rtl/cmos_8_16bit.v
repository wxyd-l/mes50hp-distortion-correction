`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Module Name: cmos_8_16bit
// Description: OV5640 DVP 8-bit -> 16-bit RGB565 packing
//
// [FIX_ROW_ALIGN]  Only change vs. the original file:
//     the byte-pair counter cnt is now cleared at every DE (href) rising edge.
//
//   original:
//       else if(de_i == 1'b1 && cnt == 2'd1) cnt <= 2'b0;
//       else if(de_i == 1'b1)                cnt <= cnt + 1'b1;
//   cnt was never re-aligned between lines; it relied on every line having an
//   even byte count.  If one line is cut short by an href glitch (odd byte
//   count), the NEXT line packs the two bytes in the wrong order
//   ({low,high} instead of {high,low}) -> the whole line has broken colours.
//   In RGB565 green spans both bytes (byte1 = RRRRRGGG, byte2 = GGGBBBBB),
//   so green is the first channel that falls apart -> "occasional green cast".
//
//   Ports, widths, clock domains and pipeline depth are unchanged
//   (pdata_o / de_o keep exactly the same latency as before).
//
// [EXPERIMENT-NEGEDGE] 本变体把 pclk 域的采样沿从 posedge 改成 negedge，
//   用于排查"DVP 数据在采样沿附近翻转"导致的椒盐噪点。
//   注意：pixel_clk 域的 3 级流水仍用 posedge pixel_clk，未改动。
//
// NOTE: this module does NOT affect pixel noise by itself.  Salt-and-pepper noise comes
//       from DVP sampling / signal integrity and is addressed by the
//       set_input_delay constraints, not here.
//////////////////////////////////////////////////////////////////////////////////
`timescale 1ns / 1ns

module cmos_8_16bit(
	input 				   pclk 		,   
	input 				   rst_n		,
	input				   de_i	        ,
	input	[7:0]	       pdata_i	    ,
    input                  vs_i         ,

    output                 pixel_clk    ,
 	output	reg			   de_o         ,
	output  reg [15:0]	   pdata_o
); 
reg			de_out1          ;
reg [15:0]	pdata_out1       ;
reg			de_out2          ;
reg [15:0]	pdata_out2       ;    
reg [1:0]   cnt             ;
wire        pclk_IOCLKBUF   ;
reg         vs_i_reg        ;
reg         enble           ;
reg [7:0] pdata_i_reg;
reg de_i_r,de_i_r1;
reg			de_out3          ;
reg [15:0]	pdata_out3       ;  
always @(negedge pclk)begin
       vs_i_reg <= vs_i ;
end
    always@(negedge pclk)
        begin
            if(!rst_n)
                enble <= 1'b0;
            else if(!vs_i_reg&&vs_i)
                enble <= 1'b1;
            else
                enble <= enble;
        end

GTP_IOCLKBUF #(
    .GATE_EN("FALSE")//
) u_GTP_IOCLKBUF (
    .CLKOUT(pclk_IOCLKBUF),// OUTPUT  
    .CLKIN(pclk), // INPUT  
    .DI(enble)     // INPUT  
);

GTP_IOCLKDIV #(
    .GRS_EN("TRUE"),
    .DIV_FACTOR("2")
) u_GTP_IOCLKDIV (
    .CLKDIVOUT(pixel_clk),// OUTPUT  
    .CLKIN(pclk_IOCLKBUF),    // INPUT  
    .RST_N(enble)     // INPUT  
);

    always@(negedge pclk)
        begin
            if(!rst_n)
                cnt <= 2'b0;
            // FIX_ROW_ALIGN: hold the byte-pair counter at 0 while DE is low,
            // so every line starts with the high byte regardless of how the
            // previous line ended (an href glitch can truncate a line to an
            // odd byte count, which used to flip the pairing of the next line).
            // NOTE: resetting on the DE *rise* would delay the counter by one
            //       cycle and shift the whole line - verified in simulation.
            else if(de_i == 1'b0)
                cnt <= 2'b0;
            else if(cnt == 2'd1)
                cnt <= 2'b0;
            else
                cnt <= cnt + 1'b1;
        end
    

    always@(negedge pclk)
        begin
            if(!rst_n)
                pdata_i_reg <= 8'b0;
            else if(de_i == 1'b1)
                pdata_i_reg <= pdata_i;
        end
    
    always@(negedge pclk)
        begin
            if(!rst_n)
                pdata_out1 <= 16'b0;
            else if(de_i == 1'b1 && cnt == 2'd1)
                pdata_out1 <= {pdata_i_reg,pdata_i};
        end
  

   always@(negedge pclk)begin
        de_i_r <= de_i;
        de_i_r1 <= de_i_r;
   end
    always@(negedge pclk)
        begin
            if(!rst_n)
                de_out1 <= 1'b0;
            else if(!de_i_r1 && de_i_r )//rising edge
                de_out1 <= 1'b1;
            else if(de_i_r1 && !de_i_r )//falling edge
                de_out1 <= 1'b0;
            else
                de_out1 <= de_out1;
        end


 
  always@(posedge pixel_clk)begin
        de_out2<=de_out1;
        de_out3<=de_out2;
        de_o   <=de_out3;
    end
    always@(posedge pixel_clk)begin
        pdata_out2<=pdata_out1;
        pdata_out3<=pdata_out2;
        pdata_o   <=pdata_out3;
    end
endmodule