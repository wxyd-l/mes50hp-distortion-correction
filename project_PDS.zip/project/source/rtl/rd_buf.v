`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: Meyesemi
// Engineer: Nill
// 
// Create Date: 15/03/23 15:02:21
// Design Name: 
// Module Name: rd_buf
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////
`define UD #1
module rd_buf #(
    parameter                     ADDR_WIDTH      = 6'd27,
    parameter                     ADDR_OFFSET     = 32'h0000_0000,
    parameter                     H_NUM           = 12'd1920,
    parameter                     V_NUM           = 12'd1080,
    parameter                     DQ_WIDTH        = 12'd32,
    parameter                     LEN_WIDTH       = 12'd16,
    parameter                     PIX_WIDTH       = 12'd24,
    parameter                     LINE_ADDR_WIDTH = 16'd19,
    parameter                     FRAME_CNT_WIDTH = 16'd8
)  (
    input                         ddr_clk,
    input                         ddr_rstn,
    input [1:0]                   page_disp_i,  // [M4-P3] from ud_page_sched
    
    input                         vout_clk,
    input                         rd_fsync,
    input                         wr_fsync,   // MOD-PAGESYNC: write-side VSYNC
    input                         rd_en,
    output                        vout_de,
    output [PIX_WIDTH- 1'b1 : 0]  vout_data,
    
    input                         init_done,
    
    output                        ddr_rreq,
    output [ADDR_WIDTH- 1'b1 : 0] ddr_raddr,
    output [LEN_WIDTH- 1'b1 : 0]  ddr_rd_len,
    input                         ddr_rrdy,
    input                         ddr_rdone,
    
    input [8*DQ_WIDTH- 1'b1 : 0]  ddr_rdata,
    input                         ddr_rdata_en 
);
    localparam RAM_WIDTH      = 16'd32;
    localparam DDR_DATA_WIDTH = DQ_WIDTH * 8;
    localparam WR_LINE_NUM    = H_NUM * PIX_WIDTH/RAM_WIDTH;
    localparam RD_LINE_NUM    = WR_LINE_NUM * RAM_WIDTH/DDR_DATA_WIDTH;
    localparam DDR_ADDR_OFFSET= RD_LINE_NUM*DDR_DATA_WIDTH/DQ_WIDTH; 
    
    //===========================================================================
    reg       rd_fsync_1d;
    reg       rd_en_1d,rd_en_2d;
    wire      rd_rst;
    reg       ddr_rstn_1d,ddr_rstn_2d;
    always @(posedge vout_clk)
    begin
        rd_fsync_1d <= rd_fsync;
        rd_en_1d <= rd_en; 
        rd_en_2d <= rd_en_1d;
        ddr_rstn_1d <= ddr_rstn;
        ddr_rstn_2d <= ddr_rstn_1d;
    end 
    assign rd_rst = ~rd_fsync_1d &rd_fsync;
    // ==== MOD-PAGESYNC BEGIN ====
    // 把写侧 VSYNC 同步到 ddr_clk，检测上升沿 = 写侧完成一帧
    reg wr_fsync_d0, wr_fsync_d1;
    always @(posedge ddr_clk)
    begin
        wr_fsync_d0 <= wr_fsync;
        wr_fsync_d1 <= wr_fsync_d0;
    end
    wire wr_frame_pulse = ~wr_fsync_d1 & wr_fsync_d0;

    // [3BUF] 与写侧 wr_buf 的 wr_page 同步的 3 页轮转计数（同一 VSYNC 边沿翻转）
    reg [1:0] wr_page_tg;
    always @(posedge ddr_clk)
    begin
        if(~ddr_rstn)
            wr_page_tg <= 2'd0;
        else if(wr_frame_pulse)
            wr_page_tg <= (wr_page_tg == 2'd2) ? 2'd0 : (wr_page_tg + 2'd1);
        else
            wr_page_tg <= wr_page_tg;
    end

    //------------------------------------------------------------------
    // [FIX-2] 读指针复位点：显示帧头（ddr_clk 域，单拍）
    //
    //   原写法 wire wr_page_edge = (page_s1 != page_d) 中，page_d 与 rd_page
    //   的时钟/条件/右值完全相同（见上面 106-113 行），二者恒等，
    //   所以该式永远是【电平】：从写侧换帧到下一个显示帧头（0~16.67ms）
    //   一直为高，wr_cnt 在这段时间里每个 ddr_clk 都被清零。
    //
    //   改成：把显示帧头 rd_fsync 同步进 ddr_clk（2 级），取上升沿 = 1 拍。
    //   原因（仿真实测）：
    //     · 读侧 60fps、写侧 30fps，一个写帧 = 2 个显示帧；
    //     · 读侧每个显示帧要读 719 行（= 整页 720 行），
    //       若只在"写侧换帧"复位，第二个显示帧会从 460160 继续爬，
    //       越过页尾 460800，并在 524288(819 行) 处回绕 -> 读到别的行。
    //     · 复位点挂在显示帧头，wr_cnt 每帧都从 0 起，一帧内 0 -> 460160，
    //       永不越页；且每个显示帧恰好复位 1 次，与相位无关。
    //------------------------------------------------------------------
    reg rd_fs_d0, rd_fs_d1;
    always @(posedge ddr_clk)
    begin
        rd_fs_d0 <= rd_fsync;
        rd_fs_d1 <= rd_fs_d0;
    end
    wire rd_frame_pulse = ~rd_fs_d1 & rd_fs_d0;   // 显示帧头, 1 拍 ddr_clk

    // [A-1] 关键：读"刚写完的那一页"，不是"正在写的那一页"！
    //   wr_buf 的写页位 = rd_frame_cnt[0]，在传感器 VSYNC 上升沿 +1，
    //   同时刻把 rd_cnt 清 0 开始写【新页】。所以"刚完成"的那一帧在【旧页】，
    //   即 ~rd_frame_cnt[0] = ~pg_s1。
    //   原实现直接锁存 page_s1（正在写的页）-> 读侧 60fps 比写侧快一倍，
    //   会读到本帧尚未写入的行（拿到上一帧的旧内容）-> 屏幕中部一道横向错位带。
    // [A-1] 页位 = 刚写完那一页的反码，并且在【写边界】当拍就切换。
    //   两种取法都试过（见 10 号文档）：
    //     · 在显示帧头锁存 ~page_s1：换页滞后到帧头，边界落在帧内时，
    //       读侧会在这段时间里读一个正在被覆盖的页 -> 实测 pgerr 最多 645/719；
    //     · 跟随写边界（本实现）：任何相位下 pgerr 恒为 0，即读侧从不在
    //       "某页正在被写"的时候读它。
    //   代价：换页点落在帧内 -> 画面在该行处有一次拼接（两帧内容，都是完整的），
    //   这是双缓冲 + 自由相位的固有限制，彻底消除需要 genlock 或三缓冲。
    // 读页 = 写页的前一页（刚写完的那一页），且【只在显示帧头切换】
    //   三页轮转下：写侧回到这一页要再等 2 个写帧（66.7ms），
    //   而读侧只需独占 16.7ms -> 有 4 倍余量，永远不会读到被覆盖的页。
    wire [1:0] rd_pg_next = (wr_page_tg == 2'd0) ? 2'd2 : (wr_page_tg - 2'd1);
    // [M4-P3] display page from ud_page_sched; switch on the CAMERA WRITE edge
    // [M4-P4] stage on the CAMERA edge, COMMIT on the DISPLAY frame edge so the
    // page swap lands in vertical blanking -> no mid-frame splice line.
    reg [1:0] page_stage;
    always @(posedge ddr_clk)
    begin
        if(!ddr_rstn)                 page_stage <= page_disp_i;
        else if(wr_frame_pulse)       page_stage <= page_disp_i;
    end
    reg [1:0] rd_page_d;
    always @(posedge ddr_clk)
    begin
        if(!ddr_rstn)                 rd_page_d <= page_disp_i;
        else if(rd_frame_pulse)       rd_page_d <= page_stage;
    end

    // 保留原信号名, 供 testbench 观察"清零事件"的拍数
    wire wr_page_edge = rd_frame_pulse;
    // ==== MOD-PAGESYNC END ====
    
    //===========================================================================
    // 注意：下面这些 wr_* 名字其实全是【读侧】信号（喂的是显示 VSYNC / DE），
    //       原命名有误导性，此处改名为 rd_*。
    reg      rd_fs_s1,rd_fs_s2,rd_fs_s3;
    wire     rd_frame_rst;

    reg      rd_en_s1,rd_en_s2,rd_en_s3;
    reg      rd_req;
    reg [11:0] rd_line;

    always @(posedge ddr_clk)
    begin
        rd_fs_s1 <= rd_fsync;
        rd_fs_s2 <= rd_fs_s1;
        rd_fs_s3 <= rd_fs_s2;

        rd_en_s1 <= rd_en;
        rd_en_s2 <= rd_en_s1;
        rd_en_s3 <= rd_en_s2;
    end

    assign rd_frame_rst = ~rd_fs_s3 && rd_fs_s2;   // 显示帧头，1 拍 ddr_clk
                                                   // （比上面的 rd_frame_pulse 晚 1 拍，
                                                   //   保证请求一定看到已更新的页位/行号）

    // [A-2] init_done 门控：DDR 里还没有一帧数据时不要发读请求
    //       （原实现该端口在模块内零引用，上电头几帧读到的是垃圾）
    // [A-3] ddr_rrdy 握手：控制器侧 rd_cmd_ready 是"忙"标志且无命令队列，
    //       忙期间发命令会取消在传传输、丢 done -> 该帧行号整体错位。
    //       这里用 2 位待发计数：只在 ready 时发，且不丢请求。
    wire req_want = init_done & ddr_rstn &
                    (rd_frame_rst || (~rd_en_s3 && rd_en_s2 && rd_line != V_NUM));
    reg [1:0] pend_cnt;
    always @(posedge ddr_clk)
    begin
        rd_req <= 1'b0;
        if(!ddr_rstn)
            pend_cnt <= 2'd0;
        else case ({req_want, (pend_cnt != 2'd0) && ddr_rrdy})
            2'b01: begin rd_req   <= 1'b1; pend_cnt <= pend_cnt - 2'd1; end
            2'b10: begin                   pend_cnt <= pend_cnt + 2'd1; end
            2'b11: begin rd_req   <= 1'b1; pend_cnt <= pend_cnt;         end
            default: ;
        endcase
    end

    always @(posedge ddr_clk)
    begin
        if(rd_frame_rst || (~ddr_rstn))
            rd_line <= 12'd1;
        else if(rd_req)
            rd_line <= rd_line + 12'd1;
    end 
    
    // [P2-2] 页内行号上限：V_NUM 行 × 每行步长 = 整页容量
    localparam PAGE_SIZE = V_NUM * DDR_ADDR_OFFSET;   // 720*640 = 460800

    reg [LINE_ADDR_WIDTH - 1'b1 :0] wr_cnt;
    always @(posedge ddr_clk)
    begin 
        if(!ddr_rstn)                                   // [P2-1] 上电复位，消除 X
            wr_cnt <= {(LINE_ADDR_WIDTH){1'b0}};
        else if(wr_page_edge)
            wr_cnt <= {(LINE_ADDR_WIDTH){1'b0}};
        else if(ddr_rdone)                              // [P2-2] 越页硬截断
            wr_cnt <= (wr_cnt + DDR_ADDR_OFFSET >= PAGE_SIZE)
                    ? {(LINE_ADDR_WIDTH){1'b0}}
                    : (wr_cnt + DDR_ADDR_OFFSET);
        else
            wr_cnt <= wr_cnt;
    end 
    
    assign ddr_rreq = rd_req;
    // [P2-3] 页位用同步到 ddr_clk 并锁存的版本，与 wr_cnt 同拍切换
    assign ddr_raddr = {rd_page_d,wr_cnt} + ADDR_OFFSET;
    assign ddr_rd_len = RD_LINE_NUM;
    
    reg  [ 8:0]           wr_addr;
    reg  [11:0]           rd_addr;
    wire [RAM_WIDTH-1:0]  rd_data;
    
    //===========================================================================
    always @(posedge ddr_clk)
    begin
        if(rd_frame_rst)
            wr_addr <= 9'd0;
        else if(ddr_rdata_en)
            wr_addr <= wr_addr + 9'd1;
        else
            wr_addr <= wr_addr;
    end 

    rd_fram_buf rd_fram_buf (
        .wr_data    (  ddr_rdata       ),// input [255:0]            
        .wr_addr    (  wr_addr         ),// input [8:0]              
        .wr_en      (  ddr_rdata_en    ),// input                    
        .wr_clk     (  ddr_clk         ),// input                    
        .wr_rst     (  ~ddr_rstn       ),// input                    
        .rd_addr    (  rd_addr         ),// input [11:0]             
        .rd_data    (  rd_data         ),// output [31:0]            
        .rd_clk     (  vout_clk        ),// input                    
        .rd_rst     (  ~ddr_rstn_2d    ) // input                    
    );
    
    reg [1:0] rd_cnt;
    wire      read_en;
    always @(posedge vout_clk)
    begin
        if(rd_en)
            rd_cnt <= rd_cnt + 1'b1;
        else
            rd_cnt <= 2'd0;
    end 
    
    always @(posedge vout_clk)
    begin
        if(rd_rst)
            rd_addr <= 'd0;
        else if(read_en)
            rd_addr <= rd_addr + 1'b1;
        else
            rd_addr <= rd_addr;
    end 
    
    reg [PIX_WIDTH- 1'b1 : 0] read_data;
    reg [RAM_WIDTH-1:0]       rd_data_1d;
    always @(posedge vout_clk)
    begin
        rd_data_1d <= rd_data;
    end 
    
    generate
    if(PIX_WIDTH == 6'd24)
    begin
        assign read_en = rd_en && (rd_cnt != 2'd3);
        
        always @(posedge vout_clk)
        begin
            if(rd_en_1d)
            begin
                if(rd_cnt[1:0] == 2'd1)
                    read_data <= rd_data[PIX_WIDTH-1:0];
                else if(rd_cnt[1:0] == 2'd2)
                    read_data <= {rd_data[15:0],rd_data_1d[31:PIX_WIDTH]};
                else if(rd_cnt[1:0] == 2'd3)
                    read_data <= {rd_data[7:0],rd_data_1d[31:16]};
                else
                    read_data <= rd_data_1d[31:8];
            end 
            else
                read_data <= 'd0;
        end 
    end
    else if(PIX_WIDTH == 6'd16)
    begin
        assign read_en = rd_en && (rd_cnt[0] != 1'b1);
        
        always @(posedge vout_clk)
        begin
            if(rd_en_1d)
            begin
                if(rd_cnt[0])
                    read_data <= rd_data[15:0];
                else
                    read_data <= rd_data_1d[31:16];
            end 
            else
                read_data <= 'd0;
        end 
    end
    else
    begin
        assign read_en = rd_en;
        
        always @(posedge vout_clk)
        begin
            read_data <= rd_data;
        end 
    end
endgenerate

    assign vout_de = rd_en_2d;
    assign vout_data = read_data;

endmodule