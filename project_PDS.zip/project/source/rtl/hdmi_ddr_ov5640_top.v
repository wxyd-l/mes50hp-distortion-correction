`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company:Meyesemi 
// Engineer: Will
// 
// Create Date: 2023-03-17  
// Design Name:  
// Module Name: 
// Project Name: 
// Target Devices: Pango
// Tool Versions: 
// Description: 
//      
// Dependencies: 
// 
// Revision:
// Revision 1.0 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////
`define UD #1
//cmos1、cmos2二选一，作为视频源输入
`define CMOS_1      //cmos1作为视频输入；
//`define CMOS_2      //cmos2作为视频输入；

module hdmi_ddr_ov5640_top#(
	parameter MEM_ROW_ADDR_WIDTH   = 15         ,
	parameter MEM_COL_ADDR_WIDTH   = 10         ,
	parameter MEM_BADDR_WIDTH      = 3          ,
	parameter MEM_DQ_WIDTH         =  32        ,
	parameter MEM_DQS_WIDTH        =  32/8
)(
	input                                sys_clk              ,//50Mhz
//OV5647
    output  [1:0]                        cmos_init_done       ,//OV5640寄存器初始化完成
    //coms1	
    inout                                cmos1_scl            ,//cmos1 i2c 
    inout                                cmos1_sda            ,//cmos1 i2c 
    input                                cmos1_vsync          ,//cmos1 vsync
    input                                cmos1_href           ,//cmos1 hsync refrence,data valid
    input                                cmos1_pclk           ,//cmos1 pxiel clock
    input   [7:0]                        cmos1_data           ,//cmos1 data
    output                               cmos1_reset          ,//cmos1 reset
    //coms2
    inout                                cmos2_scl            ,//cmos2 i2c 
    inout                                cmos2_sda            ,//cmos2 i2c 
    input                                cmos2_vsync          ,//cmos2 vsync
    input                                cmos2_href           ,//cmos2 hsync refrence,data valid
    input                                cmos2_pclk           ,//cmos2 pxiel clock
    input   [7:0]                        cmos2_data           ,//cmos2 data
    output                               cmos2_reset          ,//cmos2 reset
//DDR
    output                               mem_rst_n                 ,
    output                               mem_ck                    ,
    output                               mem_ck_n                  ,
    output                               mem_cke                   ,
    output                               mem_cs_n                  ,
    output                               mem_ras_n                 ,
    output                               mem_cas_n                 ,
    output                               mem_we_n                  ,
    output                               mem_odt                   ,
    output      [MEM_ROW_ADDR_WIDTH-1:0] mem_a                     ,
    output      [MEM_BADDR_WIDTH-1:0]    mem_ba                    ,
    inout       [MEM_DQ_WIDTH/8-1:0]     mem_dqs                   ,
    inout       [MEM_DQ_WIDTH/8-1:0]     mem_dqs_n                 ,
    inout       [MEM_DQ_WIDTH-1:0]       mem_dq                    ,
    output      [MEM_DQ_WIDTH/8-1:0]     mem_dm                    ,
    output reg                           heart_beat_led            ,
    output                               ddr_init_done             ,
//MS72xx       
    output                               rstn_out                  ,
    output                               iic_tx_scl                ,
    inout                                iic_tx_sda                ,
    output                               hdmi_int_led              ,//HDMI_OUT初始化完成
//HDMI_OUT
    output                               pix_clk                   ,//pixclk                           
    output     reg                       vs_out                    , 
    output     reg                       hs_out                    , 
    output     reg                       de_out                    ,
    output     reg[7:0]                  r_out                     , 
    output     reg[7:0]                  g_out                     , 
    output     reg[7:0]                  b_out         
);
/////////////////////////////////////////////////////////////////////////////////////
// ENABLE_DDR
    parameter CTRL_ADDR_WIDTH = MEM_ROW_ADDR_WIDTH + MEM_BADDR_WIDTH + MEM_COL_ADDR_WIDTH;//28
    parameter TH_1S = 27'd33000000;
/////////////////////////////////////////////////////////////////////////////////////
    reg  [15:0]                 rstn_1ms            ;
    wire                        cmos_scl            ;//cmos i2c clock
    wire                        cmos_sda            ;//cmos i2c data
    wire                        cmos_vsync          ;//cmos vsync
    wire                        cmos_href           ;//cmos hsync refrence,data valid
    wire                        cmos_pclk           ;//cmos pxiel clock
    wire   [7:0]                cmos_data           ;//cmos data
    wire                        cmos_reset          ;//cmos reset
    wire                        initial_en          ;
    wire[15:0]                  cmos1_d_16bit       ;
    wire                        cmos1_href_16bit    ;
    reg [7:0]                   cmos1_d_d0          ;
    reg                         cmos1_href_d0       ;
    reg                         cmos1_vsync_d0      ;
    wire                        cmos1_pclk_16bit    ;
    wire[15:0]                  cmos2_d_16bit       /*synthesis PAP_MARK_DEBUG="1"*/;
    wire                        cmos2_href_16bit    /*synthesis PAP_MARK_DEBUG="1"*/;
    reg [7:0]                   cmos2_d_d0          /*synthesis PAP_MARK_DEBUG="1"*/;
    reg                         cmos2_href_d0       /*synthesis PAP_MARK_DEBUG="1"*/;
    reg                         cmos2_vsync_d0      /*synthesis PAP_MARK_DEBUG="1"*/;
    wire                        cmos2_pclk_16bit    /*synthesis PAP_MARK_DEBUG="1"*/;
    wire[15:0]                  o_rgb565            ;
    wire                        pclk_in_test        ;    
    wire                        vs_in_test          ;
    wire                        de_in_test          ;
// [M4-P3] page-schedule + write-back wires -- MUST be before the fram_buf instance
    wire [1:0]   page_cam, page_disp, page_m4_rd, page_m4_wr;
    wire [27:0]  fb_awaddr  ;
    wire [3:0]   fb_awid    ;
    wire [3:0]   fb_awlen   ;
    wire         fb_awvalid ;
    wire         fb_awready ;
    wire [255:0] fb_wdata   ;
    wire [31:0]  fb_wstrb   ;
    wire         fb_wvalid  ;
    wire         fb_wready  ;
    wire         fb_wusero_last ;

    wire [27:0]  m4_awaddr  ;
    wire [3:0]   m4_awid_w  ;
    wire [3:0]   m4_awlen_w ;
    wire         m4_awvalid_w ;
    wire         m4_awready_w ;
    wire [255:0] m4_wdata_w ;
    wire [31:0]  m4_wstrb_w ;
    wire         m4_wvalid_w ;
    wire         m4_wready_w ;
    wire         m4_wusero_last ;
// [M4] read-channel wires -- MUST be declared before the fram_buf instance,
    wire [27:0]  fb_araddr  ;
    wire [3:0]   fb_arlen   ;
    wire         fb_arvalid ;
    wire         fb_arready ;
    wire [255:0] fb_rdata   ;
    wire         fb_rvalid  ;
    wire         fb_rlast   ;

    wire [27:0]  m4_araddr  ;
    wire [3:0]   m4_arlen   ;
    wire         m4_arvalid ;
    wire         m4_arready ;
    wire [255:0] m4_rdata   ;
    wire         m4_rvalid  ;
    wire         m4_rlast   ;    wire[15:0]                  i_rgb565            ;
    wire                        de_re               ;
//axi bus   
    wire [CTRL_ADDR_WIDTH-1:0]  axi_awaddr                 ;
    wire                        axi_awuser_ap              ;
    wire [3:0]                  axi_awuser_id              ;
    wire [3:0]                  axi_awlen                  ;
    wire                        axi_awready                ;/*synthesis PAP_MARK_DEBUG="1"*/
    wire                        axi_awvalid                ;/*synthesis PAP_MARK_DEBUG="1"*/
    wire [MEM_DQ_WIDTH*8-1:0]   axi_wdata                  ;
    wire [MEM_DQ_WIDTH*8/8-1:0] axi_wstrb                  ;
    wire                        axi_wready                 ;/*synthesis PAP_MARK_DEBUG="1"*/
    wire [3:0]                  axi_wusero_id              ;
    wire                        axi_wusero_last            ;
    wire [CTRL_ADDR_WIDTH-1:0]  axi_araddr                 ;
    wire                        axi_aruser_ap              ;
    wire [3:0]                  axi_aruser_id              ;
    wire [3:0]                  axi_arlen                  ;
    wire                        axi_arready                ;/*synthesis PAP_MARK_DEBUG="1"*/
    wire                        axi_arvalid                ;/*synthesis PAP_MARK_DEBUG="1"*/
    wire [MEM_DQ_WIDTH*8-1:0]   axi_rdata                   /* synthesis syn_keep = 1 */;
    wire                        axi_rvalid                  /* synthesis syn_keep = 1 */;
    wire [3:0]                  axi_rid                    ;
    wire                        axi_rlast                  ;
    reg  [26:0]                 cnt                        ;
    reg  [15:0]                 cnt_1                      ;
/////////////////////////////////////////////////////////////////////////////////////
//PLL
    pll u_pll (
        .clkin1   (  sys_clk    ),//50MHz
        .clkout0  (  pix_clk    ),//37.125M 720P30
        .clkout1  (  cfg_clk    ),//10MHz
        .clkout2  (  clk_25M    ),//25M
        .pll_lock (  locked     )
    );

//配置7210
    ms72xx_ctl ms72xx_ctl(
        .clk             (  cfg_clk        ), //input       clk,
        .rst_n           (  rstn_out       ), //input       rstn,
        .init_over_tx    (  init_over_tx   ), //output      init_over,                                
        .init_over_rx    (  init_over_rx   ), //output      init_over,
        .iic_tx_scl      (  iic_tx_scl     ), //output      iic_scl,
        .iic_tx_sda      (  iic_tx_sda     ), //inout       iic_sda
        .iic_scl         (  iic_scl        ), //output      iic_scl,
        .iic_sda         (  iic_sda        )  //inout       iic_sda
    );
   assign    hdmi_int_led    =    init_over_tx; 
    
    always @(posedge cfg_clk)
    begin
    	if(!locked)
    	    rstn_1ms <= 16'd0;
    	else
    	begin
    		if(rstn_1ms == 16'h2710)
    		    rstn_1ms <= rstn_1ms;
    		else
    		    rstn_1ms <= rstn_1ms + 1'b1;
    	end
    end
    
    assign rstn_out = (rstn_1ms == 16'h2710);

//配置CMOS///////////////////////////////////////////////////////////////////////////////////
//OV5640 register configure enable    
    power_on_delay	power_on_delay_inst(
    	.clk_50M                 (sys_clk        ),//input
    	.reset_n                 (1'b1           ),//input	
    	.camera1_rstn            (cmos1_reset    ),//output
    	.camera2_rstn            (cmos2_reset    ),//output	
    	.camera_pwnd             (               ),//output
    	.initial_en              (initial_en     ) //output		
    );
//CMOS1 Camera 
    reg_config	coms1_reg_config(
    	.clk_25M                 (clk_25M            ),//input
    	.camera_rstn             (cmos1_reset        ),//input
    	.initial_en              (initial_en         ),//input		
    	.i2c_sclk                (cmos1_scl          ),//output
    	.i2c_sdat                (cmos1_sda          ),//inout
    	.reg_conf_done           (cmos_init_done[0]  ),//output config_finished
    	.reg_index               (                   ),//output reg [8:0]
    	.clock_20k               (                   ) //output reg
    );

//CMOS2 Camera 
    reg_config	coms2_reg_config(
    	.clk_25M                 (clk_25M            ),//input
    	.camera_rstn             (cmos2_reset        ),//input
    	.initial_en              (initial_en         ),//input		
    	.i2c_sclk                (cmos2_scl          ),//output
    	.i2c_sdat                (cmos2_sda          ),//inout
    	.reg_conf_done           (cmos_init_done[1]  ),//output config_finished
    	.reg_index               (                   ),//output reg [8:0]
    	.clock_20k               (                   ) //output reg
    );
//CMOS 8bit转16bit///////////////////////////////////////////////////////////////////////////////////
//CMOS1
    always@(posedge cmos1_pclk)
        begin
            cmos1_d_d0        <= cmos1_data    ;
            cmos1_href_d0     <= cmos1_href    ;
            cmos1_vsync_d0    <= cmos1_vsync   ;
        end

    cmos_8_16bit cmos1_8_16bit(
    	.pclk           (cmos1_pclk       ),//input
    	.rst_n          (cmos_init_done[0]),//input
    	.pdata_i        (cmos1_d_d0       ),//input[7:0]
    	.de_i           (cmos1_href_d0    ),//input
    	.vs_i           (cmos1_vsync_d0    ),//input
    	
    	.pixel_clk      (cmos1_pclk_16bit ),//output
    	.pdata_o        (cmos1_d_16bit    ),//output[15:0]
    	.de_o           (cmos1_href_16bit ) //output
    );
//CMOS2
    always@(posedge cmos2_pclk)
        begin
            cmos2_d_d0        <= cmos2_data    ;
            cmos2_href_d0     <= cmos2_href    ;
            cmos2_vsync_d0    <= cmos2_vsync   ;
        end

    cmos_8_16bit cmos2_8_16bit(
    	.pclk           (cmos2_pclk       ),//input
    	.rst_n          (cmos_init_done[1]),//input
    	.pdata_i        (cmos2_d_d0       ),//input[7:0]
    	.de_i           (cmos2_href_d0    ),//input
    	.vs_i           (cmos2_vsync_d0    ),//input
    	
    	.pixel_clk      (cmos2_pclk_16bit ),//output
    	.pdata_o        (cmos2_d_16bit    ),//output[15:0]
    	.de_o           (cmos2_href_16bit ) //output
    );
//输入视频源选择//////////////////////////////////////////////////////////////////////////////////////////
`ifdef CMOS_1
assign     pclk_in_test    =    cmos1_pclk_16bit    ;
assign     vs_in_test      =    cmos1_vsync_d0      ;
assign     de_in_test      =    cmos1_href_16bit    ;
assign     i_rgb565        =    {cmos1_d_16bit[4:0],cmos1_d_16bit[10:5],cmos1_d_16bit[15:11]};//{r,g,b}
`elsif CMOS_2
assign     pclk_in_test    =    cmos2_pclk_16bit    ;
assign     vs_in_test      =    cmos2_vsync_d0      ;
assign     de_in_test      =    cmos2_href_16bit    ;
assign     i_rgb565        =    {cmos2_d_16bit[4:0],cmos2_d_16bit[10:5],cmos2_d_16bit[15:11]};//{r,g,b}
`endif
//////////////////////////////////////////////////////////////////////////////////////////////////////////
//修改ddr读写模块v1

    // ---------------------------------------------------------------- A3: adaptive gamma ---
// Capture side, BEFORE the frame buffer and before interpolation (gamma is non-linear,
// it cannot be commuted with bilinear). GAMMA_EN=0 -> bit-identical bypass, zero latency,
// so the verified E2 behaviour is untouched.
    localparam integer GAMMA_EN = 1;   // J 版（演示）打开自适应 Gamma；签核版改回 0
    reg  gv1 = 1'b0, gv2 = 1'b0, gv3 = 1'b0;
    always @(posedge pclk_in_test) begin gv1 <= vs_in_test; gv2 <= gv1; gv3 <= gv2; end
    wire gamma_fs = gv2 & ~gv3;              // one pulse per frame (rising edge of VSYNC)
    wire        gamma_de;
    wire [15:0] gamma_pix;
    ud_gamma565 #(.GAMMA_EN(GAMMA_EN)) u_gamma (
        .clk         (  pclk_in_test        ),
        .rst_n       (  cmos_init_done[0]   ),
        .frame_start (  gamma_fs            ),
        .de          (  de_in_test          ),
        .pix_i       (  i_rgb565            ),
        .de_o        (  gamma_de            ),
        .pix_o       (  gamma_pix           ),
        .bank_o      (                      )
    );
fram_buf fram_buf(
        .ddr_clk        (  core_clk             ),//input                         ddr_clk,
        .ddr_rstn       (  ddr_init_done        ),//input                         ddr_rstn,
        //data_in                                  
        .vin_clk        (  pclk_in_test         ),//input                         vin_clk,
        .wr_fsync       (  vs_in_test           ),//input                         wr_fsync,
        .wr_en          (  gamma_de            ),//input                         wr_en,
        .wr_data        (  gamma_pix           ),//input  [15 : 0]  wr_data,
        //data_out
        .vout_clk       (  pix_clk              ),//input                         vout_clk,
        .rd_fsync       (  vs_o               ),//input                         rd_fsync,
        .rd_en          (  de_re                ),//input                         rd_en,
        .vout_de        (  de_o               ),//output                        vout_de,
        .vout_data      (  o_rgb565             ),
        .page_cam_i     (  page_cam           ),// [M4-P3]
        .page_disp_i    (  page_disp          ),// [M4-P3]//output [PIX_WIDTH- 1'b1 : 0]  vout_data,
        .init_done      (  init_done            ),//output reg                    init_done,
        //axi bus
        .axi_awaddr     (  fb_awaddr           ),// [M4-P3] output[27:0]
        .axi_awid       (  fb_awid             ),// [M4-P3] output[3:0]
        .axi_awlen      (  fb_awlen            ),// [M4-P3] output[3:0]
        .axi_awsize     (                       ),// output[2:0]
        .axi_awburst    (                       ),// output[1:0]
        .axi_awready    (  fb_awready          ),// [M4-P3] input
        .axi_awvalid    (  fb_awvalid          ),// [M4-P3] output
        .axi_wdata      (  fb_wdata            ),// [M4-P3] output[255:0]
        .axi_wstrb      (  fb_wstrb            ),// [M4-P3] output[31:0]
        .axi_wlast      (  fb_wusero_last      ),// [M4-P3] input
        .axi_wvalid     (  fb_wvalid           ),// [M4-P3] output
        .axi_wready     (  fb_wready           ),// [M4-P3] input
        .axi_bid        (  4'd0                 ),// input[3:0]
        .axi_araddr     (  fb_araddr           ),// output[27:0]
        .axi_arid       (  axi_aruser_id        ),// output[3:0]
        .axi_arlen      (  fb_arlen            ),// output[3:0]
        .axi_arsize     (                       ),// output[2:0]
        .axi_arburst    (                       ),// output[1:0]
        .axi_arvalid    (  fb_arvalid          ),// output
        .axi_arready    (  fb_arready          ),// input
        .axi_rready     (                       ),// output
        .axi_rdata      (  fb_rdata            ),// input[255:0]
        .axi_rvalid     (  fb_rvalid           ),// input
        .axi_rlast      (  fb_rlast            ),// input
        .axi_rid        (  axi_rid              ) // input[3:0]         
    );

//////////////////////////////////////////////////////////////////////////////////////////////////////////
// [M4] arbitrary-angle (perspective included) distortion correction -- second-pass
//   clk     = sys_clk   (50 MHz)                  core domain
//   clk_ddr = core_clk  (ddrphy_clkin, 100 MHz)   AXI domain, same as fram_buf.ddr_clk
//   AXI read channel is shared with fram_buf by ud_axi_rd_arb (whole-burst round robin)
    wire         m4_frame_done ;
    // Stage 1: M4 pixel outputs have no downstream yet. Without syn_keep the
    // synthesiser prunes the whole datapath (measured: APM 1, DRM 19.5 only).
    wire         m4_de         /* synthesis syn_keep = 1 */;
    wire [15:0]  m4_data       /* synthesis syn_keep = 1 */;
    wire [11:0]  m4_x0         /* synthesis syn_keep = 1 */;
    wire [11:0]  m4_row        /* synthesis syn_keep = 1 */;

    // Real load so the datapath is kept; observe with ILA
    reg  [31:0]  m4_sink /* synthesis syn_keep = 1 */ = 32'd0;
    always @(posedge sys_clk) begin
        if (m4_de) m4_sink <= m4_sink ^ {m4_x0, m4_row, m4_data};
    end

    // frame_start: any edge of camera vsync (polarity-agnostic);
    // not re-armed until the previous M4 pass finished
    // M4 read channel master switch: 0 = off (display unaffected), 1 = on
    localparam integer M4_RD_EN = 1;
    wire m4_rd_en = (M4_RD_EN != 0);

    reg          m4_frame_req = 1'b0;
    reg          vs_d         = 1'b0;
    reg          m4_armed     = 1'b1;
    always @(posedge sys_clk) begin
        vs_d <= vs_in_test;
        if (vs_in_test != vs_d && m4_armed) begin
            m4_frame_req <= 1'b1;
            m4_armed     <= 1'b0;
        end else if (m4_frame_done) begin
            m4_frame_req <= 1'b0;
            m4_armed     <= 1'b1;
        end
    end

// ---------------------------------------------------------------- P3/P4 -----
// 4-page rotation: cam -> M4 read -> M4 write -> display, plus the write-channel
// arbiter between fram_buf (camera raw) and the M4 write master.
//   cam_page    = k mod 4        (camera writes the raw frame)
//   m4_rd_page  = previous cam   (M4 reads the frame that just finished)
//   m4_wr_page  = the 4th page   (M4 writes the corrected frame)
//   disp_page   = m4_wr_page snapshot, switched on the CAMERA WRITE edge
    reg vs_c1 = 1'b0, vs_c2 = 1'b0, vs_c3 = 1'b0;
    always @(posedge core_clk) begin vs_c1 <= vs_in_test; vs_c2 <= vs_c1; vs_c3 <= vs_c2; end
    // VSYNC has TWO edges per frame; ud_page_sched needs exactly ONE pulse per frame.
    // Use the rising edge (end of the sync pulse = start of active video).
    wire cam_fs_ddr = vs_c2 & ~vs_c3;         // rising edge only, in core_clk (3-FF sync)

    reg m4d_c1 = 1'b0, m4d_c2 = 1'b0;
    wire m4_done_edge = m4d_c1 & ~m4d_c2;
    reg  m4_done_win = 1'b0;                  // M4 finished a frame since the last camera edge
    always @(posedge core_clk) begin
        m4d_c1 <= m4_frame_done; m4d_c2 <= m4d_c1;
        if (!cmos_init_done[0])      m4_done_win <= 1'b0;
        else if (m4_done_edge)       m4_done_win <= 1'b1;
        else if (cam_fs_ddr)         m4_done_win <= 1'b0;
    end

    ud_page_sched u_pg (
        .clk             (  core_clk           ),
        .rst_n           (  cmos_init_done[0]  ),
        .cam_frame_pulse (  cam_fs_ddr         ),
        .m4_ready        (  m4_done_win        ),
        .m4_done_page    (  page_m4_wr         ),
        .disp_frame_pulse(  1'b0               ),
        .cam_page        (  page_cam           ),
        .m4_rd_page      (  page_m4_rd         ),
        .m4_wr_page      (  page_m4_wr         ),
        .disp_page       (  page_disp          ),
        .disp_page_valid (                     ),
        .page_ok         (                     )
    );

    ud_axi_wr_master #(.AW(28), .DW(256), .FW(1280), .PPR(160), .BEATS(10), .ID(4'd1)) u_m4wr (
        .clk_c       (  sys_clk             ),
        .rst_c_n     (  cmos_init_done[0]   ),
        .de          (  m4_de               ),
        .pix         (  m4_data             ),
        .out_x0      (  m4_x0               ),
        .out_row     (  m4_row              ),
        .frame_base  (  {4'b0, page_m4_wr, 22'd0} ),   // page field at [23:22], same as ud_ddr_row_rd
        .clk_d       (  core_clk            ),
        .rst_d_n     (  cmos_init_done[0]   ),
        .awvalid     (  m4_awvalid_w        ),
        .awaddr      (  m4_awaddr           ),
        .awlen       (  m4_awlen_w          ),
        .awid        (  m4_awid_w           ),
        .awready     (  m4_awready_w        ),
        .wvalid      (  m4_wvalid_w         ),
        .wdata       (  m4_wdata_w          ),
        .wstrb       (  m4_wstrb_w          ),
        .wready      (  m4_wready_w         ),
        .wusero_last (  m4_wusero_last      ),
        .hdr_cnt     (                      ),
        .drop_cnt    (                      ),
        .perr_cnt    (                      )
    );

    ud_axi_wr_arb #(.AW(28), .DW(256)) u_warb (
        .clk            (  core_clk         ),
        .rst_n          (  cmos_init_done[0]),
        .a_awvalid      (  fb_awvalid       ),
        .a_awaddr       (  fb_awaddr        ),
        .a_awlen        (  fb_awlen         ),
        .a_awid         (  fb_awid          ),
        .a_awready      (  fb_awready       ),
        .a_wvalid       (  fb_wvalid        ),
        .a_wdata        (  fb_wdata         ),
        .a_wstrb        (  fb_wstrb         ),
        .a_wready       (  fb_wready        ),
        .a_wusero_last  (  fb_wusero_last   ),
        .b_awvalid      (  m4_awvalid_w     ),
        .b_awaddr       (  m4_awaddr        ),
        .b_awlen        (  m4_awlen_w       ),
        .b_awid         (  m4_awid_w        ),
        .b_awready      (  m4_awready_w     ),
        .b_wvalid       (  m4_wvalid_w      ),
        .b_wdata        (  m4_wdata_w       ),
        .b_wstrb        (  m4_wstrb_w       ),
        .b_wready       (  m4_wready_w      ),
        .b_wusero_last  (  m4_wusero_last   ),
        .awvalid        (  axi_awvalid      ),
        .awaddr         (  axi_awaddr       ),
        .awlen          (  axi_awlen        ),
        .awid           (  axi_awuser_id    ),
        .awready        (  axi_awready      ),
        .wvalid         (                   ),
        .wdata          (  axi_wdata        ),
        .wstrb          (  axi_wstrb        ),
        .wready         (  axi_wready       ),
        .wusero_last    (  axi_wusero_last  )
    );

    ud_board_top u_m4 (
        .clk         (  sys_clk             ),
        .clk_ddr     (  core_clk            ),
        .rst_n       (  cmos_init_done[0]   ),
        .frame_start (  m4_frame_req        ),
        .frame_done  (  m4_frame_done       ),
        .cfg_a00     (  32'sd357914 ),
        .cfg_a01     (  32'sd0 ),
        .cfg_a02     (  -32'sd228885965 ),
        .cfg_a10     (  32'sd0 ),
        .cfg_a11     (  32'sd357914 ),
        .cfg_a12     (  -32'sd128670062 ),
        .cfg_h20     (  32'sd0 ),
        .cfg_h21     (  32'sd0 ),
        .cfg_w0      (  32'sd16777216  ),
        .ar_valid    (  m4_arvalid          ),
        .ar_addr     (  m4_araddr           ),
        .ar_len      (  m4_arlen            ),
        .ar_ready    (  m4_arready          ),
        .r_data      (  m4_rdata            ),
        .r_valid     (  m4_rvalid           ),
        .r_last      (  m4_rlast            ),
.page_rd     (  page_m4_rd         ),
        .de_o        (  m4_de               ),
        .data_o      (  m4_data             ),
        .out_x0      (  m4_x0               ),
        .out_row     (  m4_row              )
    );

    ud_axi_rd_arb u_arb (
        .clk        (  core_clk             ),
        .rst_n      (  cmos_init_done[0]    ),
        .en_b       (  m4_rd_en            ),
        .a_arvalid  (  fb_arvalid           ),
        .a_araddr   (  fb_araddr            ),
        .a_arlen    (  fb_arlen             ),
        .a_arready  (  fb_arready           ),
        .a_rvalid   (  fb_rvalid            ),
        .a_rdata    (  fb_rdata             ),
        .a_rlast    (  fb_rlast             ),
        .b_arvalid  (  m4_arvalid           ),
        .b_araddr   (  m4_araddr            ),
        .b_arlen    (  m4_arlen             ),
        .b_arready  (  m4_arready           ),
        .b_rvalid   (  m4_rvalid            ),
        .b_rdata    (  m4_rdata             ),
        .b_rlast    (  m4_rlast             ),
        .arvalid    (  axi_arvalid          ),
        .araddr     (  axi_araddr           ),
        .arlen      (  axi_arlen            ),
        .arready    (  axi_arready          ),
        .rvalid     (  axi_rvalid           ),
        .rdata      (  axi_rdata            ),
        .rlast      (  axi_rlast            )
    );
     always@(posedge pix_clk) begin
        r_out<={o_rgb565[15:11],3'b0   };
        g_out<={o_rgb565[10:5],2'b0    };
        b_out<={o_rgb565[4:0],3'b0     }; 
        vs_out<=vs_o;
        hs_out<=hs_o;
        de_out<=de_o;
     end
/////////////////////////////////////////////////////////////////////////////////////
//产生visa时序 
     sync_vg sync_vg(                            
        .clk            (  pix_clk              ),//input                   clk,                                 
        .rstn           (  init_done            ),//input                   rstn,                            
        .vs_out         (  vs_o                 ),//output reg              vs_out,                                                                                                                                      
        .hs_out         (  hs_o                 ),//output reg              hs_out,            
        .de_out         (                       ),//output reg              de_out, 
        .de_re          (  de_re                )    
    );  
////////////////////////////////////////////////////////////////////////////////////////////
//ddr    
        DDR3_50H u_DDR3_50H (
             .ref_clk                   (sys_clk            ),
             .resetn                    (rstn_out           ),// input
             .ddr_init_done             (ddr_init_done      ),// output
             .ddrphy_clkin              (core_clk           ),// output
             .pll_lock                  (pll_lock           ),// output

             .axi_awaddr                (axi_awaddr         ),// input [27:0]
             .axi_awuser_ap             (1'b0               ),// input
             .axi_awuser_id             (axi_awuser_id      ),// input [3:0]
             .axi_awlen                 (axi_awlen          ),// input [3:0]
             .axi_awready               (axi_awready        ),// output
             .axi_awvalid               (axi_awvalid        ),// input
             .axi_wdata                 (axi_wdata          ),
             .axi_wstrb                 (axi_wstrb          ),// input [31:0]
             .axi_wready                (axi_wready         ),// output
             .axi_wusero_id             (                   ),// output [3:0]
             .axi_wusero_last           (axi_wusero_last    ),// output
             .axi_araddr                (axi_araddr         ),// input [27:0]
             .axi_aruser_ap             (1'b0               ),// input
             .axi_aruser_id             (axi_aruser_id      ),// input [3:0]
             .axi_arlen                 (axi_arlen          ),// input [3:0]
             .axi_arready               (axi_arready        ),// output
             .axi_arvalid               (axi_arvalid        ),// input
             .axi_rdata                 (axi_rdata          ),// output [255:0]
             .axi_rid                   (axi_rid            ),// output [3:0]
             .axi_rlast                 (axi_rlast          ),// output
             .axi_rvalid                (axi_rvalid         ),// output

             .apb_clk                   (1'b0               ),// input
             .apb_rst_n                 (1'b1               ),// input
             .apb_sel                   (1'b0               ),// input
             .apb_enable                (1'b0               ),// input
             .apb_addr                  (8'b0               ),// input [7:0]
             .apb_write                 (1'b0               ),// input
             .apb_ready                 (                   ), // output
             .apb_wdata                 (16'b0              ),// input [15:0]
             .apb_rdata                 (                   ),// output [15:0]
             .apb_int                   (                   ),// output

             .mem_rst_n                 (mem_rst_n          ),// output
             .mem_ck                    (mem_ck             ),// output
             .mem_ck_n                  (mem_ck_n           ),// output
             .mem_cke                   (mem_cke            ),// output
             .mem_cs_n                  (mem_cs_n           ),// output
             .mem_ras_n                 (mem_ras_n          ),// output
             .mem_cas_n                 (mem_cas_n          ),// output
             .mem_we_n                  (mem_we_n           ),// output
             .mem_odt                   (mem_odt            ),// output
             .mem_a                     (mem_a              ),// output [14:0]
             .mem_ba                    (mem_ba             ),// output [2:0]
             .mem_dqs                   (mem_dqs            ),// inout [3:0]
             .mem_dqs_n                 (mem_dqs_n          ),// inout [3:0]
             .mem_dq                    (mem_dq             ),// inout [31:0]
             .mem_dm                    (mem_dm             ),// output [3:0]
             //debug
             .debug_data                (                   ),// output [135:0]
             .debug_slice_state         (                   ),// output [51:0]
             .debug_calib_ctrl          (                   ),// output [21:0]
             .ck_dly_set_bin            (                   ),// output [7:0]
             .force_ck_dly_en           (1'b0               ),// input
             .force_ck_dly_set_bin      (8'h05              ),// input [7:0]
             .dll_step                  (                   ),// output [7:0]
             .dll_lock                  (                   ),// output
             .init_read_clk_ctrl        (2'b0               ),// input [1:0]
             .init_slip_step            (4'b0               ),// input [3:0]
             .force_read_clk_ctrl       (1'b0               ),// input
             .ddrphy_gate_update_en     (1'b0               ),// input
             .update_com_val_err_flag   (                   ),// output [3:0]
             .rd_fake_stop              (1'b0               ) // input
       );

//心跳信号
     always@(posedge core_clk) begin
        if (!ddr_init_done)
            cnt <= 27'd0;
        else if ( cnt >= TH_1S )
            cnt <= 27'd0;
        else
            cnt <= cnt + 27'd1;
     end

     always @(posedge core_clk)
        begin
        if (!ddr_init_done)
            heart_beat_led <= 1'd1;
        else if ( cnt >= TH_1S )
            heart_beat_led <= ~heart_beat_led;
    end
                 
/////////////////////////////////////////////////////////////////////////////////////
endmodule
